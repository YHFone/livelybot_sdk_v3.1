#!/bin/bash

# step 1: build whole project ...
catkin_make

# step 2: source project environments ...
source devel/setup.bash

