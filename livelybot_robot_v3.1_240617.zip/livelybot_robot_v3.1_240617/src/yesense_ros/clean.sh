#!/bin/bash

catkin_make clean

rm -rf build/ devel/